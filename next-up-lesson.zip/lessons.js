export default {
    "tuesday": [
        { start: "07:55", end: "08:40", name: "Sport" },
        { start: "09:15", end: "10:00", name: "Vogel" },
        { start: "10:20", end: "11:05", name: "Vogel" },
        { start: "11:10", end: "11:55", name: "RuPe" },
        { start: "12:00", end: "12:45", name: "RuPe" },
        { start: "13:45", end: "14:30", name: "FiMa" },
        { start: "14:35", end: "15:20", name: "FiMa" },
        { start: "15:35", end: "16:20", name: "RuPe" },
        { start: "16:25", end: "17:10", name: "RuPe" },
    ],
};
